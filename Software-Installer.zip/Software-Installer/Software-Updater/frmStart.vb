﻿Imports System.IO

Public Class frmStart
    Sub New()
        InitializeComponent()
        Me.WindowState = FormWindowState.Minimized
        Me.ShowInTaskbar = False
    End Sub

    Private Function NetUse(ByVal ip As String) As Boolean
        Try
            Dim strProcess As String
            Dim myprocess As New Process
            Dim StartInfo As New System.Diagnostics.ProcessStartInfo

            StartInfo.FileName = "Cmd" 'starts cmd window
            StartInfo.RedirectStandardInput = True
            StartInfo.RedirectStandardOutput = True

            StartInfo.UseShellExecute = False 'required to redirect

            StartInfo.CreateNoWindow = True
            myprocess.StartInfo = StartInfo

            myprocess.Start()

            Dim SR As System.IO.StreamReader = myprocess.StandardOutput
            Dim SW As System.IO.StreamWriter = myprocess.StandardInput


            strProcess = "net use " & ip & " /delete /yes"
            System.Threading.Thread.Sleep(500)
            SW.WriteLine(strProcess)

            strProcess = "net use " & ip & " Kyohritsu#123 /User:PKI-DOMAIN\dbad"
            'strProcess = "net use \\" & ip & " " & My.Settings.PasswordAdministrator & " /User:" & ip & "\Administrator" 'NOT DOMAIN COMPUTER
            System.Threading.Thread.Sleep(500)
            SW.WriteLine(strProcess)

            strProcess = "exit"
            System.Threading.Thread.Sleep(500)
            SW.WriteLine(strProcess)

            System.Threading.Thread.Sleep(500)
            SW.Close()
            SR.Close()
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function


    Private Sub CheckUpdate()
        Try
            Dim sr As New StreamReader(Path.Combine(Application.StartupPath, "update.ini"))
            Dim source As String = String.Empty
            Dim app_name As String = String.Empty
            Dim exe As String = String.Empty

            Dim tempValue As String = String.Empty
            While Not sr.EndOfStream
                Application.DoEvents()
                tempValue = sr.ReadLine
                If tempValue.Contains("SOURCE:") Then
                    source = tempValue.Replace("SOURCE:", "").Trim
                ElseIf tempValue.Contains("APPLICATION NAME:") Then
                    app_name = tempValue.Replace("APPLICATION NAME:", "").Trim
                ElseIf tempValue.Contains("EXECUTABLE FILE:") Then
                    exe = tempValue.Replace("EXECUTABLE FILE:", "").Trim
                End If
            End While
            sr.Close()

            If NetUse(My.Settings.SharedFolder) = False Then
                MessageBox.Show(String.Format("Shared Folder: {0}", source) & vbNewLine & "Access denied.", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            If Not Directory.Exists(Path.Combine(Application.StartupPath, "Application")) Then
                Directory.CreateDirectory(Path.Combine(Application.StartupPath, "Application"))
            End If

            If source <> String.Empty And app_name <> String.Empty And exe <> String.Empty Then
                If File.GetLastWriteTime(Path.Combine(Application.StartupPath, "Application", exe)) <> File.GetLastWriteTime(Path.Combine(source, exe)) Then
                    For Each process As Process In process.GetProcessesByName(exe)
                        process.Kill()
                        process.WaitForExit()
                    Next
                    If MessageBox.Show("New update available. Would you like to update?", "Check for updates", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                        CopyFiles(source, Path.Combine(Application.StartupPath, "Application"))
                        Process.Start(Path.Combine(Application.StartupPath, "Application", exe))
                    End If
                    Application.Exit() 'Close updater
                ElseIf File.GetLastWriteTime(Path.Combine(Application.StartupPath, "Application", exe)) = File.GetLastWriteTime(Path.Combine(source, exe)) Then
                    Process.Start(Path.Combine(Application.StartupPath, "Application", exe))
                    'MessageBox.Show("Your software is up to date.", "Check for updates", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    MessageBox.Show("Application file name not found.", "Check for updates", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            Else
                MessageBox.Show("Please check your 'update.ini'." & vbNewLine & "Location: " & Application.StartupPath, "Check for updates", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Check for updates", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        Application.Exit()
    End Sub

    Private Sub CopyFiles(ByVal sourcePath As String, Optional ByVal destinationPath As String = "")
        Try
            Dim sourceDirectoryInfo As New System.IO.DirectoryInfo(sourcePath)
            If Not System.IO.Directory.Exists(destinationPath) Then
                System.IO.Directory.CreateDirectory(destinationPath)
            End If

            If Not System.IO.Directory.Exists(Path.Combine(destinationPath)) Then
                System.IO.Directory.CreateDirectory(Path.Combine(destinationPath))
            End If

            Dim fileSystemInfo As System.IO.FileSystemInfo
            For Each fileSystemInfo In sourceDirectoryInfo.GetFileSystemInfos
                Application.DoEvents()
                Dim destinationFilename As String = System.IO.Path.Combine(destinationPath, fileSystemInfo.Name)
                If TypeOf fileSystemInfo Is System.IO.FileInfo Then
                    System.IO.File.Copy(fileSystemInfo.FullName, destinationFilename, True)
                Else
                    CopyFiles(fileSystemInfo.FullName, destinationFilename)
                End If
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub frmStart_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        If Debugger.IsAttached = False Then
            Dim startupPath As String = Application.StartupPath
            Dim folderArray() As String = startupPath.Split("\")
            Dim folderName = folderArray.Last
            CreateApplicationShortcut(folderName, startupPath)
        End If
        CheckUpdate()
    End Sub

    Private Sub CreateApplicationShortcut(ByVal applicationName As String, ByVal installed_location As String)
        Try
            Dim dirLocalPath As New DirectoryInfo(installed_location)
            Dim fileSystemInfo As FileSystemInfo
            Dim oShell As Object
            Dim oLink As Object
            For Each fileSystemInfo In dirLocalPath.GetFileSystemInfos
                If TypeOf fileSystemInfo Is FileInfo Then
                    If System.IO.Path.GetFileName(fileSystemInfo.FullName) = "Software-Updater.exe" Then
                        oShell = CreateObject("WScript.Shell")
                        'Desktop
                        Dim desktopPath As String = "C:\Users\Public\Desktop"
                        oLink = oShell.CreateShortCut(System.IO.Path.Combine(desktopPath, applicationName & ".lnk"))
                        oLink.TargetPath = System.IO.Path.Combine("C:\\Systems", applicationName, System.IO.Path.GetFileName(fileSystemInfo.FullName))
                        oLink.IconLocation = System.IO.Path.Combine(installed_location, "Application", "icon.ico")
                        oLink.WindowStyle = 1
                        oLink.Save()

                        Dim startupPath As String = installed_location
                        oLink = oShell.CreateShortCut(System.IO.Path.Combine(startupPath, applicationName & ".lnk"))
                        oLink.TargetPath = System.IO.Path.Combine("C:\\Systems", applicationName, System.IO.Path.GetFileName(fileSystemInfo.FullName))
                        oLink.IconLocation = System.IO.Path.Combine(installed_location, "Application", "icon.ico")
                        oLink.WindowStyle = 1
                        oLink.Save()

                    End If
                End If
            Next
        Catch ex As Exception
            'txtLogs.Text = "Error Message: " & ex.Message
            'txtLogs.ForeColor = Color.Red
            Exit Sub
        End Try
    End Sub

End Class
