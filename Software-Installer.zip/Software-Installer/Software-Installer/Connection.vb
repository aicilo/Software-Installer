﻿Public Class Connection
    Public Shared ConnectionString As String = "Data Source=(LocalDB)\v11.0;AttachDbFilename=" & Application.StartupPath & "\DBInstaller.mdf;Integrated Security=True"
End Class
