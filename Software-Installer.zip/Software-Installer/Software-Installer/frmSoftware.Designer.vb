﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSoftware
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSoftware))
        Me.dgvSoftware = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Application = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Developer = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Source = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExecutableFilename = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnAddSoftware = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.txtLogs = New System.Windows.Forms.TextBox()
        CType(Me.dgvSoftware, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvSoftware
        '
        Me.dgvSoftware.AllowUserToAddRows = False
        Me.dgvSoftware.AllowUserToDeleteRows = False
        Me.dgvSoftware.AllowUserToResizeRows = False
        Me.dgvSoftware.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvSoftware.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvSoftware.ColumnHeadersHeight = 30
        Me.dgvSoftware.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvSoftware.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Application, Me.Developer, Me.Source, Me.ExecutableFilename})
        Me.dgvSoftware.EnableHeadersVisualStyles = False
        Me.dgvSoftware.GridColor = System.Drawing.Color.Silver
        Me.dgvSoftware.Location = New System.Drawing.Point(12, 38)
        Me.dgvSoftware.MultiSelect = False
        Me.dgvSoftware.Name = "dgvSoftware"
        Me.dgvSoftware.ReadOnly = True
        Me.dgvSoftware.RowHeadersVisible = False
        Me.dgvSoftware.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvSoftware.Size = New System.Drawing.Size(809, 244)
        Me.dgvSoftware.TabIndex = 0
        '
        'Column1
        '
        Me.Column1.Frozen = True
        Me.Column1.HeaderText = "Install"
        Me.Column1.MinimumWidth = 60
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Column1.Width = 60
        '
        'Application
        '
        Me.Application.Frozen = True
        Me.Application.HeaderText = "Application"
        Me.Application.MinimumWidth = 300
        Me.Application.Name = "Application"
        Me.Application.ReadOnly = True
        Me.Application.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Application.Width = 300
        '
        'Developer
        '
        Me.Developer.HeaderText = "Developer"
        Me.Developer.MinimumWidth = 200
        Me.Developer.Name = "Developer"
        Me.Developer.ReadOnly = True
        Me.Developer.Width = 200
        '
        'Source
        '
        Me.Source.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Source.HeaderText = "Source"
        Me.Source.MinimumWidth = 300
        Me.Source.Name = "Source"
        Me.Source.ReadOnly = True
        Me.Source.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        '
        'ExecutableFilename
        '
        Me.ExecutableFilename.HeaderText = "Executable Filename"
        Me.ExecutableFilename.MinimumWidth = 200
        Me.ExecutableFilename.Name = "ExecutableFilename"
        Me.ExecutableFilename.ReadOnly = True
        Me.ExecutableFilename.Width = 200
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Gold
        Me.Label4.Location = New System.Drawing.Point(8, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(183, 24)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Software Installer"
        '
        'btnAddSoftware
        '
        Me.btnAddSoftware.BackColor = System.Drawing.SystemColors.HotTrack
        Me.btnAddSoftware.FlatAppearance.BorderSize = 0
        Me.btnAddSoftware.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAddSoftware.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddSoftware.ForeColor = System.Drawing.Color.White
        Me.btnAddSoftware.Location = New System.Drawing.Point(12, 363)
        Me.btnAddSoftware.Name = "btnAddSoftware"
        Me.btnAddSoftware.Size = New System.Drawing.Size(108, 35)
        Me.btnAddSoftware.TabIndex = 10
        Me.btnAddSoftware.Text = "Add Software"
        Me.btnAddSoftware.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.Firebrick
        Me.btnExit.FlatAppearance.BorderSize = 0
        Me.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnExit.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.Location = New System.Drawing.Point(713, 363)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(108, 35)
        Me.btnExit.TabIndex = 11
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'txtLogs
        '
        Me.txtLogs.BackColor = System.Drawing.SystemColors.WindowText
        Me.txtLogs.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtLogs.ForeColor = System.Drawing.Color.Lime
        Me.txtLogs.Location = New System.Drawing.Point(12, 288)
        Me.txtLogs.Multiline = True
        Me.txtLogs.Name = "txtLogs"
        Me.txtLogs.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtLogs.Size = New System.Drawing.Size(809, 69)
        Me.txtLogs.TabIndex = 18
        '
        'frmSoftware
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkSlateGray
        Me.ClientSize = New System.Drawing.Size(833, 405)
        Me.Controls.Add(Me.txtLogs)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnAddSoftware)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.dgvSoftware)
        Me.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "frmSoftware"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.dgvSoftware, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dgvSoftware As System.Windows.Forms.DataGridView
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnAddSoftware As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents txtLogs As System.Windows.Forms.TextBox
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Application As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Developer As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Source As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExecutableFilename As System.Windows.Forms.DataGridViewTextBoxColumn

End Class
