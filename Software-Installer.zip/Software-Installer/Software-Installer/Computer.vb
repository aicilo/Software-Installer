﻿Imports System.Data.SqlClient
Imports System.Net

Public Class Computer
    Public Property IP_Address As String
    Public Property Description As String

    Public Sub AddComputer()
        Try
            If Not String.IsNullOrEmpty(IP_Address) And Not String.IsNullOrEmpty(Description) Then
                Dim query As String = "INSERT INTO [dbo].[tbl_computer] ([ip_address],[description]) VALUES (@ip_address,@description);"
                Using con As New SqlConnection(Connection.ConnectionString)
                    con.Open()
                    Using cmd As New SqlCommand
                        cmd.Connection = con
                        cmd.CommandType = CommandType.Text
                        cmd.CommandText = query
                        cmd.Parameters.Add("@ip_address", SqlDbType.Text).Value = IP_Address
                        cmd.Parameters.Add("@description", SqlDbType.Text).Value = Description
                        cmd.ExecuteNonQuery()
                        MessageBox.Show("Saved!", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End Using
                    con.Close()
                End Using
            Else

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Public Sub DeleteComputer(ByVal id As Integer)
        Try
            Dim query As String = "DELETE FROM [dbo].[tbl_computer] WHERE [Id] = @id;"
            Using con As New SqlConnection(Connection.ConnectionString)
                con.Open()
                Using cmd As New SqlCommand
                    cmd.Connection = con
                    cmd.CommandType = CommandType.Text
                    cmd.CommandText = query
                    cmd.Parameters.Add("@id", SqlDbType.Int).Value = id
                    cmd.ExecuteNonQuery()
                    MessageBox.Show("Deleted!", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End Using
                con.Close()
            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Function LoadComputer() As DataTable
        Dim dtTemp As New DataTable
        Try
            Dim query As String = "SELECT * FROM [dbo].[tbl_computer] ORDER BY [ip_address];"
            Using con As New SqlConnection(Connection.ConnectionString)
                con.Open()
                Using cmd As New SqlCommand
                    cmd.Connection = con
                    cmd.CommandType = CommandType.Text
                    cmd.CommandText = query
                    Using da As New SqlDataAdapter(cmd)
                        da.Fill(dtTemp)
                    End Using
                End Using
                con.Close()
            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        Return dtTemp
    End Function

    Public Function IsAddressValid(ByVal addrString As String) As Boolean
        Dim address As IPAddress = Nothing
        Return IPAddress.TryParse(addrString, address)
    End Function
End Class
