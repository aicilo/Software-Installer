﻿Imports System.IO

Public Class frmAddSoftware

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnLocation_Click(sender As Object, e As EventArgs) Handles btnLocation.Click
        Dim fbd As New FolderBrowserDialog
        If (fbd.ShowDialog() = DialogResult.OK) Then
            txtLocation.Text = fbd.SelectedPath
        End If
    End Sub

    Dim filePath = String.Empty
    Private Sub btnExecutableFilename_Click(sender As Object, e As EventArgs) Handles btnExecutableFilename.Click
        Using openFileDialog As New OpenFileDialog
            If Directory.Exists(txtLocation.Text) Then
                openFileDialog.InitialDirectory = txtLocation.Text
                openFileDialog.Filter = "Executable file (*.exe)|*.exe"
                openFileDialog.FilterIndex = 2
                openFileDialog.RestoreDirectory = True
                If openFileDialog.ShowDialog() = DialogResult.OK Then
                    filePath = openFileDialog.FileName
                End If
                txtExecutableFilename.Text = Path.GetFileName(filePath)
            Else
                MessageBox.Show("Invalid location.", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End Using


    End Sub

    Private Sub txtExecutableFilename_TextChanged(sender As Object, e As EventArgs) Handles txtExecutableFilename.TextChanged
        If Not String.IsNullOrEmpty(txtExecutableFilename.Text) Then
            txtApplicationName.ReadOnly = False
            txtApplicationName.Focus()
        Else
            txtApplicationName.ReadOnly = True
        End If
    End Sub

    Private Sub txtLocation_TextChanged(sender As Object, e As EventArgs) Handles txtLocation.TextChanged
        txtApplicationName.ReadOnly = True
        txtApplicationName.Clear()
        txtExecutableFilename.Clear()
        txtDeveloper.Clear()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim software As New Software
        software.Name = txtApplicationName.Text
        software.Location = txtLocation.Text
        software.Executable_Name = txtExecutableFilename.Text
        software.Developer = txtDeveloper.Text
        software.AddSoftware()
        txtLocation.Clear()
    End Sub

    Private Sub txtApplicationName_TextChanged(sender As Object, e As EventArgs) Handles txtApplicationName.TextChanged
        If Not String.IsNullOrEmpty(txtApplicationName.Text) Then
            txtDeveloper.ReadOnly = False
        Else
            txtDeveloper.ReadOnly = True
        End If
    End Sub
End Class