﻿Imports System.Net
Imports System.IO
Public Class frmSoftware

    Private ApplicationName As String
    Private ApplicationLocation As String
    Private Executable_Filename As String

    Private Sub frmSoftware_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RefreshSoftwareList()
    End Sub

    Private Sub RefreshSoftwareList()
        dgvSoftware.Rows.Clear()
        Dim dtTemp = New DataTable
        dtTemp.Columns.Add("SOFTWARE", System.Type.GetType("System.String"))
        dtTemp.Columns.Add("SOURCE", System.Type.GetType("System.String"))
        dtTemp.Columns.Add("EXE", System.Type.GetType("System.String"))
        dtTemp.Columns.Add("DEVELOPER", System.Type.GetType("System.String"))
        Dim sr As New StreamReader(System.IO.Path.Combine(Environment.CurrentDirectory, "data.ini"))
        Dim software As New ArrayList()
        Dim source As New ArrayList()
        Dim executable_file As New ArrayList()
        Dim developer As New ArrayList()
        Dim tempValue As String = String.Empty
        While Not sr.EndOfStream
            System.Windows.Forms.Application.DoEvents()
            tempValue = sr.ReadLine
            If tempValue.Contains("SOFTWARE:") Then
                software.Add(tempValue.Replace("SOFTWARE:", "").Trim)
            ElseIf tempValue.Contains("SOURCE:") Then
                source.Add(tempValue.Replace("SOURCE:", "").Trim)
            ElseIf tempValue.Contains("EXE:") Then
                executable_file.Add(tempValue.Replace("EXE:", "").Trim)
            ElseIf tempValue.Contains("DEVELOPER:") Then
                developer.Add(tempValue.Replace("DEVELOPER:", "").Trim)
            End If
        End While
        sr.Close()
        Try
            If software.Count = source.Count And software.Count = executable_file.Count And source.Count = executable_file.Count Then
                For i As Integer = 0 To software.Count - 1
                    If software.Item(i).ToString.Trim <> String.Empty And source.Item(i).ToString.Trim <> String.Empty And executable_file.Item(i).ToString.Trim <> String.Empty Then
                        If dtTemp.Select("SOFTWARE = '" & software.Item(i).ToString.ToUpper & "'").Count = 0 Then
                            dtTemp.Rows.Add(software.Item(i).ToString, source.Item(i).ToString, executable_file.Item(i).ToString, developer.Item(i).ToString)
                        End If
                    End If
                Next
                For Each row As DataRow In dtTemp.Rows
                    dgvSoftware.Rows.Add(Nothing, row.Item("SOFTWARE").ToString, StrConv(row.Item("DEVELOPER").ToString, VbStrConv.Uppercase), row.Item("SOURCE").ToString, row.Item("EXE").ToString)
                Next
            End If
        Catch ex As Exception
            'Exit Sub
        End Try


    End Sub

    Private Sub btnAddSoftware_Click(sender As Object, e As EventArgs) Handles btnAddSoftware.Click
        Dim frm As New frmAddSoftware
        frm.ShowDialog()
        RefreshSoftwareList()
    End Sub

    Private Sub dgvSoftware_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvSoftware.CellClick
        If e.RowIndex >= 0 And e.ColumnIndex = 0 Then
            txtLogs.ForeColor = Color.Lime
            dgvSoftware.Enabled = False
            ApplicationName = dgvSoftware.Rows(e.RowIndex).Cells("Application").Value.ToString.Trim
            ApplicationLocation = dgvSoftware.Rows(e.RowIndex).Cells("Source").Value.ToString.Trim
            Executable_Filename = dgvSoftware.Rows(e.RowIndex).Cells("ExecutableFilename").Value.ToString.Trim

            Dim installed_location As String = System.IO.Path.Combine("C:\\", "Systems", ApplicationName)

            If NetUse(My.Settings.SharedFolder) Then
                If Not System.IO.Directory.Exists(System.IO.Path.Combine(installed_location)) Then
                    System.IO.Directory.CreateDirectory(System.IO.Path.Combine(installed_location))
                End If
            End If

            If Not System.IO.Directory.Exists(System.IO.Path.Combine(installed_location, "Application")) Then
                System.IO.Directory.CreateDirectory(System.IO.Path.Combine(installed_location, "Application"))
            End If
            CopyFiles(ApplicationLocation, System.IO.Path.Combine(installed_location, "Application"))
            CreateUpdater(ApplicationLocation, ApplicationName, Executable_Filename)
            CreateApplicationShortcut(ApplicationName, installed_location)
            dgvSoftware.Enabled = True
        End If

    End Sub

#Region "Functions"

    Private Sub CreateApplicationShortcut(ByVal applicationName As String, ByVal installed_location As String)
Retry:
        Dim TryCount As Integer = 0
        Dim localDesktop As Boolean = False
        Try
            Dim dirLocalPath As New DirectoryInfo(installed_location)
            Dim fileSystemInfo As FileSystemInfo
            Dim oShell As Object
            Dim oLink As Object
            For Each fileSystemInfo In dirLocalPath.GetFileSystemInfos
                If TypeOf fileSystemInfo Is FileInfo Then
                    If System.IO.Path.GetFileName(fileSystemInfo.FullName) = "Software-Updater.exe" Then
                        oShell = CreateObject("WScript.Shell")
                        'Desktop
                        Dim desktopPath As String = String.Empty
                        If localDesktop = False Then
                            desktopPath = "C:\Users\Public\Desktop"
                        Else
                            desktopPath = My.Computer.FileSystem.SpecialDirectories.Desktop
                        End If
                        oLink = oShell.CreateShortCut(System.IO.Path.Combine(desktopPath, applicationName & ".lnk"))
                        oLink.TargetPath = System.IO.Path.Combine("C:\\Systems", applicationName, System.IO.Path.GetFileName(fileSystemInfo.FullName))
                        oLink.IconLocation = System.IO.Path.Combine(installed_location, "Application", "icon.ico")
                        oLink.WindowStyle = 1
                        oLink.Save()

                        Dim startupPath As String = installed_location
                        oLink = oShell.CreateShortCut(System.IO.Path.Combine(startupPath, applicationName & ".lnk"))
                        oLink.TargetPath = System.IO.Path.Combine("C:\\Systems", applicationName, System.IO.Path.GetFileName(fileSystemInfo.FullName))
                        oLink.IconLocation = System.IO.Path.Combine(installed_location, "Application", "icon.ico")
                        oLink.WindowStyle = 1
                        oLink.Save()
                    End If
                End If
            Next
        Catch ex As Exception
            txtLogs.Text = "Error Message: " & ex.Message
            txtLogs.ForeColor = Color.Red
            localDesktop = True
            If TryCount = 0 Then
                TryCount += 1
                GoTo Retry
            End If
            Exit Sub
        End Try
    End Sub

    Private Function NetUse(ByVal ip As String) As Boolean
        Try
            Dim strProcess As String
            Dim myprocess As New Process
            Dim StartInfo As New System.Diagnostics.ProcessStartInfo

            StartInfo.FileName = "Cmd" 'starts cmd window
            StartInfo.RedirectStandardInput = True
            StartInfo.RedirectStandardOutput = True

            StartInfo.UseShellExecute = False 'required to redirect

            StartInfo.CreateNoWindow = True
            myprocess.StartInfo = StartInfo

            myprocess.Start()

            Dim SR As System.IO.StreamReader = myprocess.StandardOutput
            Dim SW As System.IO.StreamWriter = myprocess.StandardInput


            strProcess = "net use " & ip & " /delete /yes"
            System.Threading.Thread.Sleep(500)
            SW.WriteLine(strProcess)

            strProcess = "net use " & ip & " Kyohritsu#123 /User:PKI-DOMAIN\dbad"

            System.Threading.Thread.Sleep(500)
            SW.WriteLine(strProcess)

            strProcess = "exit"
            System.Threading.Thread.Sleep(500)
            SW.WriteLine(strProcess)

            System.Threading.Thread.Sleep(500)
            SW.Close()
            SR.Close()
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function



    Private Sub CopyFiles(ByVal sourcePath As String, Optional ByVal destinationPath As String = "")
        Try
            Dim strInstalling As String = String.Format("{0} is installing. Please wait...", StrConv(ApplicationName, VbStrConv.ProperCase))

            Dim sourceDirectoryInfo As New System.IO.DirectoryInfo(sourcePath)
            If Not System.IO.Directory.Exists(destinationPath) Then
                System.IO.Directory.CreateDirectory(destinationPath)
            End If
            Dim fileSystemInfo As System.IO.FileSystemInfo
            Dim countItem As Integer = 0
            For Each fileSystemInfo In sourceDirectoryInfo.GetFileSystemInfos
                System.Windows.Forms.Application.DoEvents()
                Dim destinationFilename As String = System.IO.Path.Combine(destinationPath, fileSystemInfo.Name)
                If TypeOf fileSystemInfo Is System.IO.FileInfo Then
                    System.IO.File.Copy(fileSystemInfo.FullName, destinationFilename, True)
                Else
                    CopyFiles(fileSystemInfo.FullName, destinationFilename)
                End If
                countItem += 1
                txtLogs.Text = strInstalling & vbNewLine & String.Format("Copy file ""{0}""", fileSystemInfo.FullName)
                Threading.Thread.Sleep(200)
            Next
            txtLogs.Text = String.Format("{0} is successfully installed.", StrConv(ApplicationName, VbStrConv.ProperCase))

        Catch ex As Exception
            txtLogs.Text = "Error Message: " & ex.Message
            txtLogs.ForeColor = Color.Red
        End Try
    End Sub


    Private Sub CreateUpdater(ByVal applicationLocation As String, ByVal applicationName As String, ByVal executableFilename As String)
        Try
            Dim _location As String = System.IO.Path.Combine("C:\\", "Systems", applicationName)
            File.Copy(System.IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "Software-Updater.exe"), System.IO.Path.Combine(_location, "Software-Updater.exe"), True)
            Dim file_name As String = _location & "\update.ini"
            If File.Exists(file_name) = False Then
                File.Create(file_name).Dispose()
            End If
            File.WriteAllText(file_name, "")
            Using objWriter As StreamWriter = New StreamWriter(file_name)
                objWriter.WriteLine(String.Format("SOURCE:{0}", applicationLocation))
                objWriter.WriteLine(String.Format("APPLICATION NAME:{0}", applicationName))
                objWriter.WriteLine(String.Format("EXECUTABLE FILE:{0}", executableFilename))
                objWriter.Close()
            End Using
            Try
                Process.Start(System.IO.Path.Combine(_location, "Software-Updater.exe"))
            Catch ex As Exception
                txtLogs.Text = "Error Message: " & ex.Message & " " & String.Format("""{0}""", System.IO.Path.Combine(_location, "Software-Updater.exe"))
                txtLogs.ForeColor = Color.Red
            End Try
        Catch ex As Exception
            txtLogs.Text = "Error Message: " & ex.Message
            txtLogs.ForeColor = Color.Red
        End Try
    End Sub
#End Region


    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
        Me.Dispose()
    End Sub
End Class
