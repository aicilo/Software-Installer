﻿Imports System.IO
Public Class Software
    Public Property Name As String
    Public Property Location As String
    Public Property Executable_Name As String
    Public Property Developer As String

    Public Sub AddSoftware()
        Try
            If Not String.IsNullOrEmpty(Name) And Not String.IsNullOrEmpty(Location) And Not String.IsNullOrEmpty(Executable_Name) Then
                Using sw As StreamWriter = File.AppendText(Path.Combine(Environment.CurrentDirectory, "data.ini"))
                    sw.WriteLine()
                    sw.WriteLine("SOFTWARE:" & Name.TrimStart.TrimEnd)
                    sw.WriteLine("SOURCE:" & Location)
                    sw.WriteLine("EXE:" & Executable_Name)
                    sw.WriteLine("DEVELOPER:" & Developer)
                    sw.WriteLine("************************************")
                End Using
            End If
            MessageBox.Show("Saved successfully.", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception

        End Try
        
    End Sub
End Class
